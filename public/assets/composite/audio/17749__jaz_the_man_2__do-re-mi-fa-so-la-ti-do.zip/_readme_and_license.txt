Pack downloaded from Freesound
----------------------------------------

"Do, re, mi, fa, so, la, ti, do"

This Pack of sounds contains sounds by the following user:
 - Jaz_the_MAN_2 ( https://freesound.org/people/Jaz_the_MAN_2/ )

You can find this pack online at: https://freesound.org/people/Jaz_the_MAN_2/packs/17749/


Licenses in this Pack (see below for individual sound licenses)
---------------------------------------------------------------

Creative Commons 0: http://creativecommons.org/publicdomain/zero/1.0/


Sounds in this Pack
-------------------

  * 316913__jaz_the_man_2__si.wav.wav
    * url: https://freesound.org/s/316913/
    * license: Creative Commons 0
  * 316912__jaz_the_man_2__sol.wav.wav
    * url: https://freesound.org/s/316912/
    * license: Creative Commons 0
  * 316911__jaz_the_man_2__sol-stretched.wav.wav
    * url: https://freesound.org/s/316911/
    * license: Creative Commons 0
  * 316910__jaz_the_man_2__si-stretched.wav.wav
    * url: https://freesound.org/s/316910/
    * license: Creative Commons 0
  * 316909__jaz_the_man_2__re-stretched.wav.wav
    * url: https://freesound.org/s/316909/
    * license: Creative Commons 0
  * 316908__jaz_the_man_2__re.wav.wav
    * url: https://freesound.org/s/316908/
    * license: Creative Commons 0
  * 316907__jaz_the_man_2__mi-stretched.wav.wav
    * url: https://freesound.org/s/316907/
    * license: Creative Commons 0
  * 316906__jaz_the_man_2__mi.wav.wav
    * url: https://freesound.org/s/316906/
    * license: Creative Commons 0
  * 316905__jaz_the_man_2__fa-stretched.wav.wav
    * url: https://freesound.org/s/316905/
    * license: Creative Commons 0
  * 316904__jaz_the_man_2__fa.wav.wav
    * url: https://freesound.org/s/316904/
    * license: Creative Commons 0
  * 316903__jaz_the_man_2__la-stretched.wav.wav
    * url: https://freesound.org/s/316903/
    * license: Creative Commons 0
  * 316902__jaz_the_man_2__la.wav.wav
    * url: https://freesound.org/s/316902/
    * license: Creative Commons 0
  * 316901__jaz_the_man_2__do-octave.wav.wav
    * url: https://freesound.org/s/316901/
    * license: Creative Commons 0
  * 316900__jaz_the_man_2__do-stretched-octave.wav.wav
    * url: https://freesound.org/s/316900/
    * license: Creative Commons 0
  * 316899__jaz_the_man_2__do-stretched.wav.wav
    * url: https://freesound.org/s/316899/
    * license: Creative Commons 0
  * 316898__jaz_the_man_2__do.wav.wav
    * url: https://freesound.org/s/316898/
    * license: Creative Commons 0


